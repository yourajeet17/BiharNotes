<?php

$server = "localhost";
$user = "u667383548_root";
$password = "Hostinger.com@123";
$db = "u667383548_biharnotes";


$con = mysqli_connect($server, $user, $password,$db);

?>